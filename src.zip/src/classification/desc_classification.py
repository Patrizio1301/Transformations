import re
from pyspark.sql.functions import udf
from gensim.models import FastText

class descriptor(object):
    def __init__(self, df, col, epochs):
        self.df=df
        self.col=col
        self.model=FastText(size=6, window=1, min_count=4)
        self.epochs=epochs

    @property
    def desc_list(self):
        def splitter(x):
            return re.split("[, \-!?:]+", x)

        descriptor=udf(lambda descriptor: splitter(descriptor))
        return self.df.select(
            self.df['*'],
            descriptor(self.col).alias('{}_aux'.format(self.col))
        )

    @property
    def run(self):
        descriptors=self.desc_list
        self.model.build_vocab(
            sentences=descriptors
        )
        self.model.train(
            sentences=descriptors,
            total_examples=len(descriptors),
            epochs=self.epochs
        )



