import tensorflow as tf
import numpy as np
import pandas as pd
import sys
from tensorflow.keras.callbacks import ModelCheckpoint as ModelCheckPoint

def coompliation(
        model,
        learning_rate
):
    adamOpti = tf.keras.optimizers.Adam(lr=learning_rate)
    model.compile(loss=['sparse_categorical_crossentropy', 'sparse_categorical_crossentropy', 'sparse_categorical_crossentropy'],
                  optimizer=adamOpti,
                  metrics=['sparse_categorical_accuracy', 'sparse_categorical_accuracy', 'sparse_categorical_accuracy'])
    print(model.summary())


def training(model,
             epochs,
             train_dataset,
             test_dataset
):

    print('*' * 20)
    print('Training model...')
    sys.stdout.flush()
    checkpoint = ModelCheckPoint(
        filepath='weights.{epoch:02d}.hdf5',
        verbose=1,
        save_best_only=True,
        save_weights_only=True
    )

    x_train, y_train=train_dataset
    x_test, y_test=test_dataset
    sample_size=1009
    validation_size=8
    history = model.fit(
        x_train,
        y_train,
        epochs=epochs,
        verbose=1,
        validation_data=(x_test, y_test),
        callbacks=[checkpoint]
    )

    print('*' * 20)
    print('Plotting history...')
    sys.stdout.flush()
    #plot_training_info(['loss'], True, history.history)
    print('*' * 20)
    print('Evaluating best model...')
    sys.stdout.flush()
    #metrics = model.evaluate(test_data, steps=10)
    #print(metrics)

