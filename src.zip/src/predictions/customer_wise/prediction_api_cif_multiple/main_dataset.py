from predictions.customer_wise.prediction_api_cif_multiple.model import model
from predictions.customer_wise.prediction_api_cif_multiple.training_dataset import training, coompliation
from predictions.customer_wise.prediction_api_cif_multiple.input_dataset import Input as Input_dataset
from predictions.customer_wise.prediction_api_cif_multiple.input_array import Input as Input_array
from predictions.customer_wise.prediction_api_cif_multiple.input_gen import Input as Input_gen
import pandas as pd
import tensorflow as tf
import numpy as np

class Main(object):
    TOTAL_CIF = 42+100
    TOTAL_CUSTOMER = 10+100
    TOTAL_MONTH = 12+100
    TOTAL_DAYS = 31+100
    DIM_CONCAT = 6 + 15 + 1 + 1 + 18

    def __init__(
            self,
            path,
            df,
            steps_per_epoch: int=1,
            validation_steps: int=1,
            step: int=1,
            input_steps = 3,
            future_steps=3,
            batch_size = 3,
            customer_embdg_len=5,
            month_embdg_len = 6,
            day_embdg_len = 15,
            cif_embdg_len = 20,
            epochs = 70,
            learning_rate = 0.0001
    ):
        self.path=path
        self.df=df
        self.steps_per_epoch=steps_per_epoch
        self.validation_steps=validation_steps
        self.step=step
        self.epochs=epochs
        self.input_steps=input_steps
        self.future_steps=future_steps
        self.batch_size=batch_size
        self.customer_embdg_len=customer_embdg_len
        self.month_embdg_len=month_embdg_len
        self.day_embdg_len=day_embdg_len
        self.cif_embdg_len=cif_embdg_len
        self.learning_rate=learning_rate
        self.model=self.model()


    @property
    def input(self):
        return Input_dataset(
            df=self.df,
            batch_size=self.batch_size,
            input_steps=self.input_steps,
            future_steps=self.future_steps
        )

    def model(self):
        return model(
            input_steps=self.input_steps,
            total_month=self.TOTAL_MONTH,
            total_day=self.TOTAL_DAYS,
            total_cif=self.TOTAL_CIF,
            total_customer=self.TOTAL_CUSTOMER,
            customer_embedding_length=self.customer_embdg_len,
            month_embedding_length=self.month_embdg_len,
            day_embedding_length=self.day_embdg_len,
            cif_embedding_length=self.cif_embdg_len,
            dim_concat=self.DIM_CONCAT
        )

    def compilation(self):
        return coompliation(
            model=self.model,
            learning_rate=self.learning_rate
        )

    def training(self):
        return training(
            model=self.model,
            epochs=self.epochs,
            steps_per_epoch=self.steps_per_epoch,
            validation_steps=self.validation_steps,
            train_dataset=self.input.train_dataset,
            test_dataset=self.input.test_dataset
        )

    def save(self):
        self.model.save(self.path)

    def load(self):
        tf.keras.models.load_model(self.path)