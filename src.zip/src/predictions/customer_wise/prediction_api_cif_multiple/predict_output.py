import pandas as pd

class Prediction(object):
    def __init__(self, model, x_test, batch_size, future_steps):
        self.model=model
        self.x_test=x_test
        self.batch_size=batch_size
        self.future_steps=future_steps

    @property
    def predictions(self):
        return self.model.predict(self.x_test, self.batch_size)

    def run(self, path):
        year = self.x_test[0].argmax(axis=-1)
        month = self.x_test[1].argmax(axis=-1)
        day = self.x_test[2].argmax(axis=-1)
        amount = self.x_test[3]
        month_pred = self.predictions[0].argmax(axis=-1)
        day_pred = self.predictions[1].argmax(axis=-1)
        results= pd.DataFrame(
            {
                'year': year,
                'month': month,
                'day': day,
                'amount': amount,
                'month_pred': month_pred,
                'day_pred':day_pred
             }
        )
        results.to_csv(path)