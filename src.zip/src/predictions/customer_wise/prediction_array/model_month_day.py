import tensorflow as tf
from tensorflow.keras.layers import Embedding, Reshape, Input, Concatenate, LSTM, Dense, Dropout

def modelling(input_steps,
              total_category,
              total_month,
              total_day,
              category_embedding_length,
              month_embedding_length,
              day_embedding_length,
              dim_concat):

    ###############################################################
    ######################       YEAR        ####################
    ###############################################################
    input_year = Input(
        shape=(input_steps, ),
        dtype='float32',
        name="input_year"
    )
    year = Reshape(
        target_shape=(input_steps, 1),
        name="reshape_year"
    )(input_year)


    ###############################################################
    ######################       AMOUNT        ####################
    ###############################################################
    input_amount = Input(
        shape=(input_steps,),
        dtype='float32',
        name="input_amount"
    )
    amount = Reshape(
        target_shape=(input_steps, 1),
        name="reshape_amount"
    )(input_amount)

    ###############################################################
    ######################      MONTH         #####################
    ###############################################################
    input_month = Input(
        shape=(input_steps,),
        dtype='float32',
        name="input_month"
    )
    embedding_month = Embedding(
        input_dim=total_month,
        output_dim=month_embedding_length,
        input_length=input_steps,
        name='embedding_month'
    )(input_month)
    month = Reshape(
        target_shape=(input_steps,month_embedding_length,),
        name='reshape_month'
    )(embedding_month)

    ###############################################################
    ######################      DAY           #####################
    ###############################################################
    input_day = Input(
        shape=(input_steps,),
        dtype='float32',
        name="input_day"
    )
    embedding_day = Embedding(
        input_dim=total_day,
        output_dim=day_embedding_length,
        input_length=input_steps,
        name='embedding_day'
    )(input_day)
    day = Reshape(
        target_shape=(input_steps,day_embedding_length,),
        name="reshape_day"
    )(embedding_day)

    ###############################################################
    ######################      CATEGORY      #####################
    ###############################################################
    input_category = Input(
        shape=(input_steps,),
        dtype='float32',
        name="input_category"
    )
    embedding_category = Embedding(
        input_dim=total_category,
        output_dim=category_embedding_length,
        input_length=input_steps,
        name='embedding_category'
    )(input_category)
    category = Reshape(
        target_shape=(input_steps,category_embedding_length),
        name="reshape_category"
    )(embedding_category)


    ###############################################################
    ###################      CONCATENATION       ##################
    ###############################################################
    concat = Concatenate(axis=2)([year, month, day, amount, category])

    # Everything continues in a single branch
    lstmConcat = LSTM(
        1024,
        return_sequences=True,
        input_shape=(input_steps, dim_concat)
    )(concat)

    #reshape_1 = Reshape((INPUT_ACTIONS, 2))(input_time)
    #merge embeddings (5 x 50) and times (5 x 1), to have 5 x 51

    dense_1 = Dense(1024, activation='relu')(lstmConcat)
    drop_1 = Dropout(0.8)(dense_1)
    dense_2 = Dense(1024, activation='relu')(drop_1)
    drop_2 = Dropout(0.8)(dense_2)
    dense_month= Dense(1024, activation='relu')(drop_2)
    dense_day = Dense(1024, activation='relu')(drop_2)
    output_month = Dense(total_month, activation='softmax',name="output_month")(dense_month)
    output_day = Dense(total_day, activation='softmax', name="output_day")(dense_day)

    model = tf.keras.Model(inputs=[input_year, input_month, input_day, input_amount, input_category],
                           outputs=[output_month, output_day])
    return model