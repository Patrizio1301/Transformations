import tensorflow as tf
import numpy as np
import pandas as pd
import sys
from src.prediction.visualizations import plot_training_info
from tensorflow.keras.callbacks import ModelCheckpoint as ModelCheckPoint

def training(model,
             input_steps,
             batch_size,
             epochs,
             learning_rate,
             x_train,
             y_train,
             x_test,
             y_test):

    print('*' * 20)
    print('Building model...')
    sys.stdout.flush()

    adamOpti = tf.keras.optimizers.Adam(lr=learning_rate)
    model.compile(loss=['categorical_crossentropy', 'categorical_crossentropy'],
                  optimizer=adamOpti,
                  metrics=['accuracy', 'accuracy'])
    print(model.summary())
    sys.stdout.flush()

    print('*' * 20)
    print('Training model...')
    sys.stdout.flush()
    checkpoint = ModelCheckPoint(
        filepath='weights.{epoch:02d}.hdf5',
        verbose=0,
        save_best_only=True,
        save_weights_only=True
    )

    history = model.fit(x=x_train,
                        y=y_train,
                        batch_size=batch_size,
                        epochs=epochs,
                        validation_data=(x_test, y_test),
                        shuffle=False,
                        callbacks=[checkpoint])

    print('*' * 20)
    print('Plotting history...')
    sys.stdout.flush()
    #plot_training_info(['loss'], True, history.history)
    print('*' * 20)
    print('Evaluating best model...')
    sys.stdout.flush()
    #metrics = model.evaluate(test_data, steps=10)
    #print(metrics)

