import numpy as np
import tensorflow as tf


class Input(object):
    def __init__(self, df, input_steps,future_steps):
        self.df =df
        self.input_steps=input_steps
        self.future_steps=future_steps

    @staticmethod
    def f_input(
            row,
            input_steps,
            future_steps,
            slice=1
    ):
        input_array = np.array(
            [
                np.array(row['year_list']),
                np.array(row['month_list']),
                np.array(row['day_list']),
                np.array(row['importe_list']),
                np.array(row['cif_id_list'])
            ]
        )
        output_array = np.array(
            [
                np.array(row['month_list']),
                np.array(row['day_list'])
            ]
        )
        _, n = input_array.shape
        for i in range(0, n - input_steps + 1 - future_steps):
            input_indices = range(i * slice, i * slice + input_steps, 1)
            output_indices = range(i * slice + future_steps,
                                   i * slice + input_steps + future_steps, 1)
            yield input_array[:, input_indices], output_array[:, output_indices]

    @property
    def input_data_generator(self):
        df2 = self.df.filter("cif_id_list_cnt>10")
        func=lambda x: self.f_input(
            row=x,
            input_steps=self.input_steps,
            future_steps=self.future_steps
        )
        input=df2.rdd.flatMap(func).collect()
        return tf.data.Dataset.from_generator(
            generator=input,
            output_types=((tf.float32, tf.float32, tf.float32, tf.float32, tf.float32), (tf.float32, tf.float32))
        )

    @property
    def initializer(self):
        return self.input_data_generator.make_initializable_iterator()


