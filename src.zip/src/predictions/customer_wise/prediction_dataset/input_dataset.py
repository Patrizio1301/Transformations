import tensorflow as tf
import pandas as pd
from src.preprocessing.dataset_easy import Datasets

class Input(object):
    def __init__(self, df, future_steps):
        self.df=df
        self.future_steps=future_steps

    @property
    def features(self):
        input = tf.convert_to_tensor(pd.iloc[:(-1) * self.future_steps, :].values)
        input_ = tf.data.Dataset.from_tensor_slices(input)
        return Datasets(input_).window_dataset(3, 1)

    @staticmethod
    def get_one_hot(col, number_of_cat_values):
        return tf.one_hot(indices=col, depth=number_of_cat_values)

    @property
    def target(self):
        df = pd.iloc[self.future_steps:, :]
        # year=tf.convert_to_tensor(df['year'].values)
        month = self.get_one_hot(col=df['month'].values, number_of_cat_values=12)
        day = self.get_one_hot(col=df['day'].values, number_of_cat_values=31)
        # amount=tf.convert_to_tensor(df['importe'].values)
        dataset = tf.data.Dataset.from_tensor_slices((month, day))
        return Datasets(dataset).window_dataset(3, 1)

class Splitted(object):
    def __init__(self, df, split, future_steps):
        self.df=df
        self.split=split
        self.future_steps=future_steps

    #def length(self):

class Dataset_INPUT(object):
    def __init__(self, df, split, future_steps):
        self.df = df
        self.split = split
        self.future_steps = future_steps

