from src.preprocessing.dataset_easy import Datasets
import tensorflow as tf
import numpy as np
import pandas as pd

class Input(object):
    def __init__(self, future_steps, df):
        self.future_steps=future_steps
        self.df=df

    @property
    def input(self):
        df_pandas=self.df.toPandas().sort_values(by='fecha_trans')
        df_pandas['importe'] = df_pandas['importe'].astype(np.float)
        df_pandas['category'] = df_pandas['category'].astype(np.int)
        df_dataset = df_pandas[['year', 'month', 'day', 'importe', 'category']]
        return df_dataset

    @property
    def prediction_set(self):
        x= self.input.iloc[(-1) * (self.future_steps + 3):(-1) * self.future_steps, :]
        n, _=x.shape
        year = [x['year'][i:i+self.future_steps].values for i in range(n-self.future_steps+1)]
        month = [x['month'][i:i+self.future_steps].values for i in range(n-self.future_steps+1)]
        day = [x['day'][i:i+self.future_steps].values for i in range(n-self.future_steps+1)]
        importe = [x['importe'][i:i+self.future_steps].values for i in range(n-self.future_steps+1)]
        category = [x['category'][i:i+self.future_steps].values for i in range(n-self.future_steps+1)]
        y= self.input.iloc[self.future_steps:-1, :]
        return [year, month, day, importe, category], y


    def multivariate_data(self, dataset, target, start_index, end_index,
                          history_size, target_size, step, single_step=False):
        data = []
        labels = []

        start_index = start_index + history_size
        if end_index is None:
            end_index = len(dataset) - target_size

        for i in range(start_index, end_index):
            indices = range(i - history_size, i, step)
            data.append(dataset[indices])

            if single_step:
                labels.append(target[i + target_size])
            else:
                labels.append(target[i:i + target_size])

        return np.array(data), np.array(labels)


    def features(self, df: pd.DataFrame):
        self.multivariate_data(dataset=df, target=df[:,1,2], start_index=0, end_index=7,
                               history_size=3, target_size=3, step=1)
        month=tf.data.Dataset.from_tensor_slices(df['month'].values)
        day=tf.data.Dataset.from_tensor_slices(df['day'].values)
        importe=tf.data.Dataset.from_tensor_slices(df['importe'].values)
        category=tf.data.Dataset.from_tensor_slices(df['category'].values)
        input_=tf.data.Dataset.zip((year, month, day, importe, category))
        return Datasets(input_).window_dataset(3, 1).batch(1)

    @staticmethod
    def get_one_hot(col, number_of_cat_values):
        return tf.one_hot(indices=col, depth=number_of_cat_values)

    def target(self, df: pd.DataFrame):
        month= self.get_one_hot(col=df['month'].values, number_of_cat_values=12)
        day =  self.get_one_hot(col=df['day'].values, number_of_cat_values=31)
        dataset=tf.data.Dataset.from_tensor_slices((month, day))
        return  dataset.batch(1)

    @property
    def get_training_data(self):
        x_train = self.input.iloc[:(-1) * (self.future_steps + 1), :]
        y_train = self.input.iloc[self.future_steps:-1, :]
        x_train=self.features(x_train)
        y_train=self.target(y_train)
        return tf.data.Dataset.zip((x_train, y_train)).repeat()

    @property
    def get_test_data(self):
        x_test = self.input.iloc[(-1) * (self.future_steps + 3):(-1) * self.future_steps, :]
        y_test = self.input.iloc[(-1) * (self.future_steps):, :]
        x_test=self.features(x_test)
        y_test=self.target(y_test)
        return tf.data.Dataset.zip((x_test, y_test)).repeat()
