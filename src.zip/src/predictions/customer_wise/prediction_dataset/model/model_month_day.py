import tensorflow as tf
import numpy as np
import sys
from src.prediction.visualizations import plot_training_info

def modelling(input_steps,
              total_category,
              total_month,
              total_day,
              category_embedding_length,
              month_embedding_length,
              day_embedding_length,
              dim_concat):

    ###############################################################
    ######################       YEAR        ####################
    ###############################################################
    input_year = tf.keras.layers.Input(shape=(2, ), dtype='float32', name="input_year")
    year = tf.keras.layers.Reshape(target_shape=(input_steps, 2), name="reshape_year")(input_year)

    ###############################################################
    ######################       AMOUNT        ####################
    ###############################################################
    #input_amount = tf.keras.layers.Input(shape=(1,), dtype='float32', name="input_amount")
    #amount = tf.keras.layers.Reshape(target_shape=(input_steps, 1), name="reshape_amount")(input_amount)

    ###############################################################
    ######################      MONTH         #####################
    ###############################################################
    input_month = tf.keras.layers.Input(shape=(1,), dtype='float32', name="input_month")
    #month_abc = tf.keras.backend.squeeze(input_month,axis=0)
    #month_abc = tf.keras.layers.Reshape(target_shape=(input_steps,), name='month_abc')(input_month)
    embedding_month = tf.keras.layers.Embedding(input_dim=total_month,
                                                  output_dim=month_embedding_length,
                                                  input_length=input_steps)(input_month)
    month = tf.keras.layers.Reshape(
        target_shape=(month_embedding_length,),
        name='reshape_month')(embedding_month)

    ###############################################################
    ######################      DAY           #####################
    ###############################################################
    input_day = tf.keras.layers.Input(shape=(1,), dtype='float32', name="input_day")
    #day_abc = tf.keras.layers.Reshape(target_shape=(input_steps,), name='input_abc')(input_day)
    #day_abc = tf.keras.backend.squeeze(input_day, axis=0)
    embedding_day = tf.keras.layers.Embedding(input_dim=total_day,
                                                  output_dim=day_embedding_length,
                                                  input_length=input_steps)(input_day)
    day = tf.keras.layers.Reshape(target_shape=(day_embedding_length,), name="reshape_day")(embedding_day)

    ###############################################################
    ######################      CATEGORY      #####################
    ###############################################################
    input_category = tf.keras.layers.Input(shape=(1,), dtype='float32', name="input_category")
    #cat_abc = tf.keras.layers.Reshape(target_shape=(input_steps, ), name='cat_abc')(input_category)
    #cat_abc = tf.keras.backend.squeeze(input_category, axis=0)
    embedding_category = tf.keras.layers.Embedding(input_dim=total_category,
                                                    output_dim=category_embedding_length,
                                                    input_length=input_steps)(input_category)
    category = tf.keras.layers.Reshape(target_shape=(category_embedding_length,), name="reshape_category")(embedding_category)

    # "concat" mode can only merge layers with matching output shapes except for the concat axis.
    concat = tf.keras.layers.Concatenate(axis=2)([year, month, day, category])

    # Everything continues in a single branch
    lstmConcat = tf.keras.layers.LSTM(512,
                                     return_sequences=False,
                                     input_shape=(input_steps, dim_concat))(concat)

    #reshape_1 = Reshape((INPUT_ACTIONS, 2))(input_time)
    #merge embeddings (5 x 50) and times (5 x 1), to have 5 x 51

    dense_1 = tf.keras.layers.Dense(1024, activation='relu')(lstmConcat)
    drop_1 = tf.keras.layers.Dropout(0.8)(dense_1)
    dense_2 = tf.keras.layers.Dense(1024, activation='relu')(drop_1)
    drop_2 = tf.keras.layers.Dropout(0.8)(dense_2)
    output_month = tf.keras.layers.Dense(total_month, activation='softmax',name="output_month")(drop_2)
    output_day = tf.keras.layers.Dense(total_day, activation='softmax', name="output_day")(drop_2)

    model = tf.keras.Model(inputs=[input_year, input_month, input_day, input_category],
                           outputs=[output_month, output_day])
    return model