import numpy as np
import pandas as pd


class Input(object):
    def __init__(self, input_steps, df, step, slice, future_steps):
        self.input_steps=input_steps
        self.df=df
        self.step=step
        self.slice=slice
        self.future_steps=future_steps

    @property
    def input(self):
        df_pandas=self.df.toPandas().sort_values(by='fecha_trans')
        df_pandas['cif_id']=df_pandas['cif_id'].astype(int)
        return df_pandas[['year', 'month', 'day', 'importe', 'cif_id']]

    @property
    def length(self):
        r, _=self.input.shape
        return r

    def arraywise(
            self,
            col,
            start_index: int,
            end_index: int,
            input_steps: int,
            slice: int,
            future_steps: int=1
    ):
        new_array=[]
        for i in range(start_index, end_index):
            indices = range((i - input_steps)*slice, (i - input_steps)*slice+input_steps)
            new_array.append(col[indices])
        return new_array


    def features(
            self,
            df: pd.DataFrame,
            start_index: int,
            end_index: int,
            input_steps: int,
            slice: int
    ):
        year=self.arraywise(
            col=df['year'].values,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps,
            slice=slice
        )
        month=self.arraywise(
            col=df['month'].values,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps,
            slice=slice
        )
        day=self.arraywise(
            col=df['day'].values,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps,
            slice=slice
        )
        importe=self.arraywise(
            col=df['importe'].values,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps,
            slice=slice
        )
        cif=self.arraywise(
            col=df['cif_id'].values,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps,
            slice=slice
        )
        return [year, month, day, importe, cif]

    def get_one_hot_alternative(
            self,
            col,
            num_cat_values,
            start_index,
            end_index,
            input_steps,
            slice=1
    ):
        new_array = []
        for i in range(start_index, end_index):
            indices = range((i - input_steps)*slice, (i - input_steps)*slice+input_steps)
            sub_array = []
            for j in indices:
                sub_array.append(self.create_vector(num_cat_values, col[j]))
            new_array.append(sub_array)
        return new_array

    def create_vector(self, length, number):
        row = np.zeros(length)
        row[number] = 1
        return row

    def target(
            self,
            df: pd.DataFrame,
            start_index: int,
            end_index: int,
            input_steps: int,
            slice: int
    ):
        month= self.get_one_hot_alternative(
            col=df['month'].values,
            num_cat_values=12,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps,
            slice=slice
        )
        day =  self.get_one_hot_alternative(
            col=df['day'].values,
            num_cat_values=31,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps,
            slice=slice
        )
        cif =  self.get_one_hot_alternative(
            col=df['cif_id'].values,
            num_cat_values=7004,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps,
            slice=slice
        )
        return  [month, day, cif]

    @property
    def train_data(self):
        start_index=self.input_steps
        end_index=self.length-self.input_steps-self.future_steps+1
        x_train=self.features(
            df=self.input,
            start_index=self.input_steps,
            end_index=end_index,
            input_steps=self.input_steps,
            slice=self.slice
        )
        y_train=self.target(
            df=self.input,
            start_index=start_index+self.future_steps,
            end_index=end_index+self.input_steps,
            input_steps=self.input_steps,
            slice=self.slice
        )
        return x_train, y_train

    @property
    def test_data(self):
        start_index = self.length - self.input_steps
        end_index = self.length - self.input_steps+1
        x_test=self.features(
            df=self.input,
            start_index=start_index,
            end_index=end_index,
            input_steps=self.input_steps,
            slice=self.slice
        )
        y_test=self.target(
            df=self.input,
            start_index=start_index+self.input_steps,
            end_index=end_index+self.input_steps,
            input_steps=self.input_steps,
            slice=self.slice
        )
        return x_test, y_test
