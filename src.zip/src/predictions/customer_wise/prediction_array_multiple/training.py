import tensorflow as tf
import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Training(object):
    def __init__(
            self,
            model,
            input_steps,
            batch_size,
            epochs,
            learning_rate,
            x_train,
            y_train,
            x_test,
            y_test
    ):
        self.model = model
        self.input_steps = input_steps
        self.batch_size = batch_size
        self.epochs = epochs
        self.learning_rate = learning_rate
        self.x_train = x_train
        self.y_train = y_train
        self.x_test = x_test
        self.y_test = y_test

    @property
    def optimization(self):
        return tf.keras.optimizers.Adam(lr=self.learning_rate)

    def compilation(self):
        self.model.compile(
            loss=['categorical_crossentropy', 'categorical_crossentropy'],
            optimizer=self.optimization,
            metrics=['accuracy', 'accuracy']
        )
        return logger.info('The model has been '
                           'compiled sucessfully.')

    @property
    def checkpoint(self):
        return tf.keras.callbacks.ModelCheckpoint(
            filepath='weights.{epoch:02d}.hdf5',
            verbose=0,
            save_weights_only=True
        )

    @property
    def run(self):
        self.compilation()
        print(self.model.summary())
        self.model.fit(
            x=self.x_train,
            y=self.y_train,
            batch_size=self.batch_size,
            epochs=self.epochs,
            validation_data=(self.x_test, self.y_test),
            shuffle=False,
            callbacks=[self.checkpoint]
        )
        return logger.info('The model has been '
                       'trained sucessfully.')

