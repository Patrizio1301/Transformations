from predictions.customer_wise.prediction_array_multiple.model import model
from predictions.customer_wise.prediction_array_multiple.training import Training
from predictions.customer_wise.prediction_array_multiple import Input

class Main(object):
    CATEGORY_EMBEDDING_LENGTH = 18
    DIM_CONCAT = 6 + 15 + 1 + 1 + CATEGORY_EMBEDDING_LENGTH
    TOTAL_CATEGORY = 33
    TOTAL_MONTH = 12
    TOTAL_DAYS = 31
    TOTAL_CUSTOMERS = 31

    def __init__(
            self,
            df,
            input_steps,
            batch_size,
            month_embg_len,
            day_embg_len,
            category_embg_len,
            epochs,
            learning_rate
    ):
        self.df=df
        self.input_steps=input_steps
        self.batch_size=batch_size
        self.month_embg_len = month_embg_len
        self.day_embg_len = day_embg_len
        self.category_embg_len = category_embg_len
        self.epochs = epochs
        self.learning_rate = learning_rate

    @property
    def input(self):
        return Input(
            input_steps=self.input_steps,
            df=self.df
        )

    @property
    def model(self):
        return model(
            input_steps=self.input_steps,
            total_month=self.TOTAL_MONTH,
            total_day=self.TOTAL_DAYS,
            total_category=self.TOTAL_CATEGORY,
            month_embedding_length=self.month_embg_len,
            day_embedding_length=self.day_embg_len,
            category_embedding_length=self.CATEGORY_EMBEDDING_LENGTH,
            dim_concat=self.DIM_CONCAT
        )

    @property
    def run(self):
        x_train, y_train = self.input.train_data
        x_test, y_test = self.input.test_data
        return Training(
            model=self.model,
            input_steps=self.input_steps,
            batch_size=self.batch_size,
            epochs=self.epochs,
            learning_rate=self.learning_rate,
            x_train=x_train,
            y_train=y_train,
            x_test=x_test,
            y_test=y_test
        ).run

    def prediction(self, x):
        output = self.model.predict(x)
        print(output)
        month = output[0].argmax(axis=2)
        day = output[1].argmax(axis=2)
        print(month, day)
