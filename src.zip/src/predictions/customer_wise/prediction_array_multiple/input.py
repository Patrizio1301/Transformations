import numpy as np
import pandas as pd
from sklearn import preprocessing

class Input(object):
    def __init__(self, input_steps, df):
        self.input_steps=input_steps
        self.df=df

    @property
    def input(self):
        df_pandas=self.df.toPandas().sort_values(by='fecha_trans')
        df_pandas['year'] = df_pandas['year'].astype(np.float)
        df_pandas['importe'] = df_pandas['importe'].astype(np.float)
        df_pandas['category'] = df_pandas['category'].astype(np.int)
        df_pandas['customer'] = df_pandas['customer'].astype(np.int)
        df_pandas['importe']  = self.scaling(df_pandas[['importe']].values.astype(float))
        df_pandas['year'] = self.scaling(df_pandas[['year']].values.astype(float))
        df_dataset = df_pandas[['customer', 'year', 'month', 'day', 'importe', 'category']]
        return df_dataset

    def scaling(self, col):
        # Create a minimum and maximum processor object
        min_max_scaler = preprocessing.MinMaxScaler()
        # Create an object to transform the data to fit minmax processor
        x_scaled = min_max_scaler.fit_transform(col)
        # Run the normalizer on the dataframe
        return pd.DataFrame(x_scaled)

    def arraywise(
            self,
            col,
            start_index,
            end_index,
            input_steps,
            step=1
    ):
        new_array=[]
        for i in range(start_index, end_index):
            indices = range(i - input_steps, i, step)
            new_array.append(col[indices])
        return new_array


    def features(
            self,
            df: pd.DataFrame,
            start_index,
            end_index,
            input_steps
    ):
        customer = self.arraywise(
            col=df['customer'].values,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps
        )
        year=self.arraywise(
            col=df['year'].values,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps
        )
        month=self.arraywise(
            col=df['month'].values,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps
        )
        day=self.arraywise(
            col=df['day'].values,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps
        )
        importe=self.arraywise(
            col=df['importe'].values,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps
        )
        category=self.arraywise(
            col=df['category'].values,
            start_index=start_index,
            end_index=end_index,
            input_steps=input_steps
        )
        return [customer, year, month, day, importe, category]

    def get_one_hot_alternative(
            self,
            col,
            num_cat_values,
            start_index,
            end_index,
            history_size,
            step=1
    ):
        new_array = []
        for i in range(start_index, end_index):
            indices = range(i - history_size, i, step)
            sub_array = []
            for j in indices:
                sub_array.append(self.create_vector(num_cat_values, col[j]))
            new_array.append(sub_array)
        return new_array

    def create_vector(
            self,
            length,
            number
    ):
        row = np.zeros(length)
        row[number] = 1
        return row

    def target(
            self,
            df: pd.DataFrame,
            start_index,
            end_index,
            input_steps
    ):
        month= self.get_one_hot_alternative(
            col=df['month'].values,
            num_cat_values=12,
            start_index=start_index,
            end_index=end_index,
            history_size=input_steps
        )
        day =  self.get_one_hot_alternative(
            col=df['day'].values,
            num_cat_values=31,
            start_index=start_index,
            end_index=end_index,
            history_size=input_steps
        )
        return  [month, day]

    @property
    def train_data(self):
        x_train=self.features(
            df=self.input,
            start_index=3,
            end_index=5,
            input_steps=self.input_steps
        )
        y_train=self.target(
            df=self.input,
            start_index=3+self.input_steps,
            end_index=5+self.input_steps,
            input_steps=self.input_steps
        )
        return x_train, y_train

    @property
    def test_data(self):
        x_test=self.features(
            df=self.input,
            start_index=5,
            end_index=6,
            input_steps=self.input_steps
        )
        y_test=self.target(
            df=self.input,
            start_index=5+3,
            end_index=6+3,
            input_steps=self.input_steps
        )
        return x_test, y_test
