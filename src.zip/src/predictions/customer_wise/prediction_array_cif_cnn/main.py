from predictions.customer_wise.prediction_array_cif_cnn.model_month_day import modelling
from predictions.customer_wise.prediction_array_cif_cnn.training_month_day import training
from predictions.customer_wise.prediction_array_cif_cnn.input import Input
import pandas as pd
import tensorflow as tf
import numpy as np


class Main(object):
    TOTAL_CIF = 7004
    TOTAL_MONTH = 12
    TOTAL_DAYS = 31
    DIM_CONCAT = 6 + 15 + 1 + 1 + 18

    def __init__(
            self,
            path,
            df,
            input_steps = 3,
            batch_size = 1,
            month_embdg_len = 6,
            day_embdg_len = 15,
            cif_embdg_len = 50,
            epochs = 70,
            learning_rate = 0.00005
    ):
        self.path=path
        self.df=df
        self.epochs=epochs
        self.input_steps=input_steps
        self.batch_size=batch_size
        self.month_embdg_len=month_embdg_len
        self.day_embdg_len=day_embdg_len
        self.cif_embdg_len=cif_embdg_len
        self.learning_rate=learning_rate
        self.model=self.model()


    @property
    def input(self):
        return Input(
            input_steps=self.input_steps,
            df=self.df
        )

    def model(self):
        return modelling(
            input_steps=self.input_steps,
            total_month=self.TOTAL_MONTH,
            total_day=self.TOTAL_DAYS,
            total_cif=self.TOTAL_CIF,
            month_embedding_length=self.month_embdg_len,
            day_embedding_length=self.day_embdg_len,
            cif_embedding_length=self.cif_embdg_len,
            dim_concat=self.DIM_CONCAT
        )

    def training(self):
        x_train, y_train = self.input.train_data
        x_test, y_test = self.input.test_data
        return training(
            model=self.model,
            input_steps=self.input_steps,
            batch_size=self.batch_size,
            epochs=self.epochs,
            learning_rate=self.learning_rate,
            x_train=x_train,
            y_train=y_train,
            x_test=x_test,
            y_test=y_test
        )

    def prediction(self, x, y):
        output = self.model.predict(x)
        month=np.array([a.tolist() for a in y[0][0]]).argmax(axis=1)
        day = np.array([a.tolist() for a in y[1][0]]).argmax(axis=1)
        cif = np.array([a.tolist() for a in y[2][0]]).argmax(axis=1)
        month_pred=output[0].argmax(axis=2)
        day_pred=output[1].argmax(axis=2)
        cif_pred = output[2].argmax(axis=2)
        results = pd.DataFrame({'month': month,
                                'day': day,
                                'cif': cif,
                                'month_pred': month_pred[0],
                                'day_pred': day_pred[0],
                                'cif_pred': cif_pred[0]})
        results.to_csv('results_004948143000001184_version2_cif_inputsteps_15.csv')
        return self.model.predict(x)

    def save(self):
        self.model.save(self.path)

    def load(self):
        tf.keras.models.load_model(self.path)