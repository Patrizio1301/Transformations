import tensorflow as tf
import numpy as np
import pandas as pd
import sys
from tensorflow.keras.callbacks import ModelCheckpoint as ModelCheckPoint

def coompliation(
        model,
        learning_rate
):
    adamOpti = tf.keras.optimizers.Adam(lr=learning_rate)
    model.compile(loss=['sparse_categorical_crossentropy', 'sparse_categorical_crossentropy', 'sparse_categorical_crossentropy'],
                  optimizer=adamOpti,
                  metrics={'output_month':'sparse_categorical_accuracy',
                           'output_day':'sparse_categorical_accuracy',
                           'output_cif':'sparse_categorical_accuracy'})
    print(model.summary())


def training(
        model,
        epochs: int,
        steps_per_epoch: int,
        validation_steps: int,
        train_dataset,
        test_dataset
):

    print('*' * 20)
    print('Training model...')
    sys.stdout.flush()
    checkpoint = ModelCheckPoint(
        filepath='weights.{epoch:02d}.hdf5',
        verbose=1,
        save_best_only=True,
        save_weights_only=True
    )

    sample_size=1009
    validation_size=8
    history = model.fit(
        train_dataset,
        epochs=epochs,
        steps_per_epoch=steps_per_epoch,
        validation_steps=validation_steps,
        verbose=1,
        validation_data=test_dataset,
        callbacks=[checkpoint]
    )

    print('*' * 20)
    print('Plotting history...')
    sys.stdout.flush()
    #plot_training_info(['loss'], True, history.history)
    print('*' * 20)
    print('Evaluating best model...')
    sys.stdout.flush()
    #metrics = model.evaluate(test_data, steps=10)
    #print(metrics)

