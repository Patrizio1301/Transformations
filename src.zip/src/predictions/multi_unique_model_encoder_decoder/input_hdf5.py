import numpy as np
import tensorflow as tf
import h5py

class InputFile(object):
    def __init__(self, df):
        self.df=df

    def __call__(self, path, *args, **kwargs):
        def get_col(name):
            return self.df.select(name).rdd.flatMap(lambda x: x).collect()

        input_array = np.array(
            [
                np.array([int(x) for x in get_col('customer_id')]),
                np.array([int(x) for x in get_col('year')]),
                np.array([int(x) for x in get_col('month')]),
                np.array([int(x) for x in get_col('day')]),
                np.array([int(x) for x in get_col('dayofyear')]),
                np.array([float(x) for x in get_col('importe')]),
                np.array([int(x) for x in get_col('cif_id')]),
                np.array([int(x) for x in get_col('cat_id')])
            ]
        )
        file = h5py.File(path, "w")
        return file.create_dataset("dataset", data=input_array)



class Input(object):
    def __init__(self, batch_size, input_steps,future_steps, path):
        self.batch_size=batch_size
        self.input_steps=input_steps
        self.future_steps=future_steps
        self.path=path

    @property
    def get_dataset(self):
        file = h5py.File(self.path, "r")
        return file['dataset'].value

    def f_input(
            self,
            input_steps,
            future_steps,
            start=0,
            end=0,
            slice=1
    ):
        file = h5py.File(self.path, "r")
        dataset = file['dataset'].value
        _, n = dataset.shape
        if start < 0:
            for i in range(n - input_steps + 1 - future_steps + start, n - input_steps + 1 - future_steps - end):
                input_indices = range(i * slice, i * slice + input_steps, 1)
                input = dataset[:, input_indices]
                yield input[0], input[1], input[2], input[3], input[4], input[5], input[6], input[7]
        else:
            for i in range(start, n - input_steps + 1 - future_steps - end):
                input_indices = range(i * slice, i * slice + input_steps, 1)
                input = dataset[:, input_indices]
                yield input[0], input[1], input[2], input[3], input[4], input[5], input[6], input[7]

    def f_output(
            self,
            input_steps,
            future_steps,
            start=0,
            end=0,
            slice=1
    ):
        file = h5py.File(self.path, "r")
        data=file['dataset'].value
        dataset=np.array([data[2],data[3],data[6],data[0]])
        _, n = dataset.shape
        if start < 0:
            for i in range(n - input_steps + 1 - future_steps + start, n - input_steps + 1 - future_steps - end):
                output_indices = range(i * slice + future_steps, i * slice + input_steps + future_steps, 1)
                output = np.reshape(dataset[:, output_indices], (4, input_steps, 1))
                yield output[0], output[1], output[2], output[3]
        else:
            for i in range(start, n - input_steps + 1 - future_steps - end):
                output_indices = range(i * slice + future_steps, i * slice + input_steps + future_steps, 1)
                output = np.reshape(dataset[:, output_indices], (4, input_steps, 1))
                yield output[0], output[1], output[2], output[3]

    def input(self, start, end, slice):
        return tf.data.Dataset.from_generator(
            generator=lambda: self.f_input(
                self.input_steps,
                self.future_steps,
                start,
                end,
                slice
            ),
            output_types=(tf.int32, tf.float32, tf.int32, tf.int32, tf.int32, tf.float32, tf.int32, tf.int32),
            output_shapes=(
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,))
            )
        )

    def output(self, start, end, slice):
        """
        Create a `tf.data.Dataset` from a layer_op (as a generator).

        :return: a `tf.data.Dataset`
        """
        return tf.data.Dataset.from_generator(
            generator=lambda: self.f_output(
                self.input_steps,
                self.future_steps,
                start,
                end,
                slice
            ),
            output_types=(tf.int32, tf.int32, tf.int32, tf.int32),
            output_shapes=(
                tf.TensorShape((self.input_steps,1)),
                tf.TensorShape((self.input_steps,1)),
                tf.TensorShape((self.input_steps,1)),
                tf.TensorShape((self.input_steps,1))
            )
        )

    @property
    def train_dataset(self):
        tup = (
            self.input(0, self.input_steps + 1, 1),
            self.output(0, self.input_steps + 1, 1)
        )
        return tf.data.Dataset.zip(tup).shuffle(buffer_size=400).repeat().batch(self.batch_size)

    @property
    def test_dataset(self):
        tup=(
            self.input(-1,0, 1),
            self.output(-1,0, 1)
        )
        return tf.data.Dataset.zip(tup).repeat().batch(self.batch_size)

    @property
    def prediction_input(self):
        input_gen = self.f_input(
            self.input_steps,
            self.future_steps,
            start=-1,
            end=0,
            slice=1
        )
        return list(input_gen)

    @property
    def prediction_output(self):
        input_gen = self.f_output(
            self.input_steps,
            self.future_steps,
            start=-1,
            end=0,
            slice=1
        )
        return list(input_gen)