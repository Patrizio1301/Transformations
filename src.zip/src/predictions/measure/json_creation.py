import numpy as np
from src.predictions.multi_unique_model_encoder_decoder.input_hdf5 import Input
from src.transactionModel.measure.prediction import Prediction


class TransactionSet(object):
    def __init__(self, trans_arr):
        self.trans_arr=trans_arr

    @property
    def registers(self):
        transpose=np.transpose(self.trans_arr)
        trans_reg = {}
        i=0
        for reg in transpose:
            trans_reg[i] = {'customer': reg[0], 'cif': reg[1], 'month': reg[2], 'day': reg[3]}
            i += 1
        return trans_reg

    @property
    def trans_dict(self):
        customers=np.unique(self.trans_arr[0])
        trans_dict={k:{} for k,v in dict.fromkeys(customers).items()}
        for key, register in self.registers.items():
            if register['cif'] in trans_dict[register['customer']].keys():
                trans_dict[register['customer']][register['cif']][key] = \
                    {'month': register['month'], 'day': register['day']}
            else:
                trans_dict[register['customer']][register['cif']] = {}
                trans_dict[register['customer']][register['cif']][key]=\
                    {'month': register['month'], 'day': register['day']}
        return trans_dict

    def get_trans(self, customer, cif):
        if customer in self.trans_dict.keys():
            if cif in  self.trans_dict[customer].keys():
                return self.trans_dict[customer][cif]
            else:
                return None
        else:
            return None

    def get_best_prediction(self, customer, cif, month, day, daydiff):
        if self.get_trans(customer, cif):
            choises=self.get_trans(customer, cif).copy()
            monthmatch={}
            for key, value in choises.items():
                if choises[key]['month']==month:
                    choises[key]['dif']=abs(choises[key]['day']-day)
                    monthmatch[key]=choises[key]
            if bool(monthmatch):
                least=[None, daydiff]
                for key, value in monthmatch.items():
                    if monthmatch[key]['dif']<daydiff and monthmatch[key]['dif']<least[1]:
                        least=[key, daydiff]
                return least[0]
            else:
                return None
        else:
            return None

class Measure(object):
    def __init__(self, model, input_steps, input_path, batch_size):
        self.model=model
        self.input_steps=input_steps
        self.input_path=input_path
        self.batch_size=batch_size

    @property
    def input(self):
        return Input(
            path=self.input_path,
            batch_size=self.batch_size,
            input_steps=self.input_steps,
            future_steps=self.input_steps
        )

    @property
    def prediction(self):
        return Prediction(
            model=self.model,
            x_test=self.input.prediction_input[0],
            y_test=self.input.prediction_output[0],
            input_steps=self.input_steps
        )

    @property
    def validation_set(self):
        return TransactionSet(
            trans_arr=self.prediction.output
        )

    @property
    def predicted_set(self):
        return TransactionSet(
            trans_arr=self.prediction.output_pred
        )

    def __call__(self, daydiff):
        well_pred = []
        validation=self.validation_set.registers
        predicted=self.predicted_set
        for key, value in validation.items():
            customer = validation[key]['customer']
            cif = validation[key]['cif']
            month = validation[key]['month']
            day = validation[key]['day']
            well_pred.append(predicted.get_best_prediction(
                customer=customer,
                cif=cif,
                month=month,
                day=day,
                daydiff=daydiff
            ))
        return len([i for i in well_pred if i]) / len(well_pred)





if __name__ == "__main__":


    measurement=Measure(
        model_path='/home/x260220/PycharmProjects/main/results/prediction/encoder_decoder_model/model/model_48_40clientes_test2.h5',
        input_steps=200,
        input_path='/home/x260220/PycharmProjects/main/results/prediction/encoder_decoder_model/history_data/input_data_40.hdf5',
        batch_size=10
    )

    print("With maximal +/- 5 days of deviation the hit rate is {} %. ".format(measurement(daydiff=6)))
    print("With maximal +/- 2 days of deviation the hit rate is {} %. ".format(measurement(daydiff=3)))
    print("With maximal +/- 1 days of deviation the hit rate is {} %. ".format(measurement(daydiff=2)))
    print("With maximal +/- 0 days of deviation the hit rate is {} %. ".format(measurement(daydiff=1)))


















