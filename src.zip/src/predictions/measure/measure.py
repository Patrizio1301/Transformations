import pandas as pd

class measure(object):
    def __init__(self, df: pd.DataFrame):
        self.df=df

    def add_year(self, df, month, yearold, yearnew):
        return df.where(df[month].isin([7,8,9,10,11], yearold, yearnew))

    def create_date(self, df,  year, month, day):
        return pd.to_datetime(df[[year, month, day]])

    def dif_datetimea(self, df, date1, date2):
        return (df[date1] - df[date2]).dt.days

    def __call__(self, df):
        df['year']=self.add_year(df, 'month', '2019', '2020')
        df['year_pred'] = self.add_year(df, 'month_pred', '2019', '2020')
        df['date']=self.create_date(df, 'year', 'month', 'day')
        df['date_pred'] = self.create_date(df, 'year_pred', 'month_pred', 'day_pred')
        df['dif_date']=self.dif_datetimea(df, 'date', 'date_pred')
        df['evaluation']=df.where(abs(df['dif_date'])<6, 1, 0)
        _, n = df.shape()
        return sum(df['evaluation'])/n









