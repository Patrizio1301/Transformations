import numpy as np
import tensorflow as tf

class Input(object):
    def __init__(self, df, batch_size, input_steps,future_steps):
        self.df =df
        self.batch_size=batch_size
        self.input_steps=input_steps
        self.future_steps=future_steps

    @property
    def data(self):
        return self.df.filter("cif_id_list_cnt>40")

    @staticmethod
    def f_output(
            row: np.array,
            input_steps,
            future_steps,
            start=0,
            end=0,
            slice=1
    ):
        output_array = np.array(
            [
                np.array(row['month_list']),
                np.array(row['day_list']),
                np.array(row['cif_id_list'])
            ]
        )
        _, n = output_array.shape
        if start < 0:
            for i in range(n - input_steps + 1 - future_steps +start, n - input_steps + 1 - future_steps - end):
                output_indices = range(i * slice + future_steps, i * slice + input_steps + future_steps, 1)
                output= np.reshape(output_array[:, output_indices], (3,input_steps,1))
                yield output[0],output[1],output[2]
        else:
            for i in range(start, n - input_steps + 1 - future_steps-end):
                output_indices = range(i * slice + future_steps, i * slice + input_steps + future_steps, 1)
                output = np.reshape(output_array[:, output_indices], (3, input_steps, 1))
                yield output[0], output[1], output[2]

    @staticmethod
    def f_input(
            row: np.array,
            input_steps,
            future_steps,
            start=0,
            end=0,
            slice=1
    ):
        input_array = np.array(
            [
                np.array(row['customer_id_list']),
                np.array(row['year_list']),
                np.array(row['month_list']),
                np.array(row['day_list']),
                np.array(row['dayofyear_list']),
                np.array(row['importe_list']),
                np.array(row['cif_id_list'])
            ]
        )
        _, n = input_array.shape
        if start < 0:
            for i in range(n - input_steps + 1 - future_steps+start, n - input_steps + 1 - future_steps-end):
                input_indices = range(i * slice, i * slice + input_steps, 1)
                input = input_array[:, input_indices]
                yield input[0],input[1],input[2],input[3],input[4],input[5],input[6]
        else:
            for i in range(start, n - input_steps + 1 - future_steps-end):
                input_indices = range(i * slice, i * slice + input_steps, 1)
                input=input_array[:, input_indices]
                yield input[0],input[1],input[2],input[3],input[4],input[5],input[6]

    @staticmethod
    def input_data_generator(df, function, input_steps, future_steps, start, end):
        func=lambda x: function(x, input_steps, future_steps, start=start, end=end)
        result = df.rdd.flatMap(func)
        while True:
            for x in list(result.toLocalIterator()):
                yield x

    @staticmethod
    def prediction_data_generator(df, function, input_steps, future_steps, start, end):
        func=lambda x: function(x, input_steps, future_steps, start=start, end=end)
        result = df.rdd.flatMap(func)
        for x in list(result.toLocalIterator()):
            yield x

    def input(self, input_steps, future_steps, start, end):
        input_gen=self.input_data_generator(
            self.data,
            self.f_input,
            input_steps,
            future_steps,
            start,
            end
        )
        return tf.data.Dataset.from_generator(
            generator=lambda: input_gen,
            output_types=(tf.int32, tf.float32, tf.int32, tf.int32, tf.int32, tf.float32, tf.int32),
            output_shapes=(
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,)),
                tf.TensorShape((self.input_steps,))
            )
        )

    def output(self, input_steps, future_steps, start, end):
        """
        Create a `tf.data.Dataset` from a layer_op (as a generator).

        :return: a `tf.data.Dataset`
        """
        output_gen=self.input_data_generator(
            self.data,
            self.f_output,
            input_steps,
            future_steps,
            start,
            end
        )
        return tf.data.Dataset.from_generator(
            generator=lambda: output_gen,
            output_types=(tf.int32, tf.int32, tf.int32),
            output_shapes=(
                tf.TensorShape((self.input_steps,1)),
                tf.TensorShape((self.input_steps,1)),
                tf.TensorShape((self.input_steps,1))
            )
        )

    @property
    def train_dataset(self):
        tup=(
            self.input(self.input_steps, self.future_steps, 0,self.input_steps+1),
            self.output(self.input_steps, self.future_steps, 0,self.input_steps+1)
        )
        return tf.data.Dataset.zip(tup).batch(1)

    @property
    def test_dataset(self):
        tup=(
            self.input(self.input_steps, self.future_steps, -1,0),
            self.output(self.input_steps, self.future_steps, -1,0)
        )
        return tf.data.Dataset.zip(tup).batch(1)

    @property
    def prediction_input(self):
        input_gen=self.prediction_data_generator(
            self.data,
            self.f_input,
            self.input_steps,
            self.future_steps,
            start=-1,
            end=0
        )
        return list(input_gen)

    @property
    def prediction_output(self):
        input_gen=self.prediction_data_generator(
            self.data,
            self.f_output,
            self.input_steps,
            self.future_steps,
            start=-1,
            end=0
        )
        return list(input_gen)




