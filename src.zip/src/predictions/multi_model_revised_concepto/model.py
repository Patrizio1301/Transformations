import tensorflow as tf
from tensorflow.keras.layers import Embedding, Reshape, Input, Concatenate, LSTM, Dense, Dropout
from tensorflow.core.protobuf import rewriter_config_pb2
from tensorflow.keras.backend import set_session
tf.keras.backend.clear_session()  # For easy reset of notebook state.

def model(
        input_steps,
        total_customer,
        total_cif,
        total_month,
        total_day,
        total_category,
        total_descriptor,
        customer_embedding_length,
        cif_embedding_length,
        category_embedding_length,
        month_embedding_length,
        day_embedding_length,
        dim_concat
):

    ###############################################################
    ######################       Customer       ###################
    ###############################################################
    input_customer = Input(
        shape=(input_steps, ),
        dtype='float32',
        name="input_customer"
    )
    embedding_customer = Embedding(
        input_dim=total_customer,
        output_dim=customer_embedding_length,
        input_length=input_steps,
        name='embedding_customer'
    )(input_customer)

    customer = Reshape(
        target_shape=(input_steps,customer_embedding_length,),
        name='reshape_customer'
    )(embedding_customer)

    ###############################################################
    ######################       YEAR        ####################
    ###############################################################
    input_year = Input(
        shape=(input_steps, ),
        dtype='float32',
        name="input_year"
    )
    year = Reshape(
        target_shape=(input_steps, 1),
        name="reshape_year"
    )(input_year)


    ###############################################################
    ######################       AMOUNT        ####################
    ###############################################################
    input_amount = Input(
        shape=(input_steps,),
        dtype='float32',
        name="input_amount"
    )
    amount = Reshape(
        target_shape=(input_steps, 1),
        name="reshape_amount"
    )(input_amount)

    ###############################################################
    ######################      MONTH         #####################
    ###############################################################
    input_month = Input(
        shape=(input_steps,),
        dtype='float32',
        name="input_month"
    )
    embedding_month = Embedding(
        input_dim=total_month,
        output_dim=month_embedding_length,
        input_length=input_steps,
        name='embedding_month'
    )(input_month)
    month = Reshape(
        target_shape=(input_steps,month_embedding_length,),
        name='reshape_month'
    )(embedding_month)

    ###############################################################
    ######################      DAY           #####################
    ###############################################################
    input_day = Input(
        shape=(input_steps,),
        dtype='float32',
        name="input_day"
    )
    embedding_day = Embedding(
        input_dim=total_day,
        output_dim=day_embedding_length,
        input_length=input_steps,
        name='embedding_day'
    )(input_day)
    day = Reshape(
        target_shape=(input_steps,day_embedding_length,),
        name="reshape_day"
    )(embedding_day)

    ###############################################################
    ######################      CIF      ##########################
    ###############################################################
    input_cif= Input(
        shape=(input_steps,),
        dtype='float32',
        name="input_cif"
    )
    embedding_cif = Embedding(
        input_dim=total_cif,
        output_dim=cif_embedding_length,
        input_length=input_steps,
        name='embedding_cif'
    )(input_cif)
    cif = Reshape(
        target_shape=(input_steps,cif_embedding_length),
        name="reshape_cif"
    )(embedding_cif)

    ###############################################################
    ######################      CATEGORY      #####################
    ###############################################################
    input_category= Input(
        shape=(input_steps,),
        dtype='float32',
        name="input_category"
    )
    embedding_category = Embedding(
        input_dim=total_category,
        output_dim=category_embedding_length,
        input_length=input_steps,
        name='embedding_category'
    )(input_category)
    category = Reshape(
        target_shape=(input_steps,category_embedding_length),
        name="reshape_category"
    )(embedding_category)

    ###############################################################
    ######################   DESCRIPTOR        ####################
    ###############################################################
    input_descriptor = Input(
        shape=(input_steps, total_descriptor),
        dtype='float32',
        name="input_descriptor"
    )
    descriptor = Reshape(
        target_shape=(input_steps, total_descriptor),
        name="reshape_descriptor"
    )(input_descriptor)



    ###############################################################
    ###################      CONCATENATION       ##################
    ###############################################################
    concat = Concatenate(axis=2)([customer, year, month, day, amount, cif, category, descriptor])

    # Everything continues in a single branch
    lstmConcat = LSTM(
        1024,
        return_sequences=True,
        input_shape=(input_steps, dim_concat)
    )(concat)

    #reshape_1 = Reshape((INPUT_ACTIONS, 2))(input_time)
    #merge embeddings (5 x 50) and times (5 x 1), to have 5 x 51

    dense_1 = Dense(1024, activation='relu')(lstmConcat)
    drop_1 = Dropout(0.2)(dense_1)
    dense_2 = Dense(1024, activation='relu')(drop_1)
    drop_2 = Dropout(0.2)(dense_2)
    #output_year = Dense(1, activation='softmax', name="output_year")(drop_2)
    output_month = Dense(total_month, activation='softmax',name="output_month")(drop_2)
    output_day = Dense(total_day, activation='softmax', name="output_day")(drop_2)
    output_cif = Dense(total_cif, activation='softmax', name="output_cif")(drop_2)

    model = tf.keras.Model(inputs=[input_customer, input_year, input_month, input_day, input_amount, input_cif, input_category, input_descriptor],
                           outputs=[output_month, output_day, output_cif])
    return model