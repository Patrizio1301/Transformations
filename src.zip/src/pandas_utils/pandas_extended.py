import pandas as pd

class pandas_extended(object):
    def __init__(self, df):
        self.df =df

    @classmethod
    def read_from_csv(cls, path):
        return cls(df=pd.read_csv(path))

    def add_perc(self, amount_column_list):
        df = self.df.copy()
        for col in amount_column_list:
            column_name= "{}_perc".format(col)
            df[column_name] = df[col] / df[col].sum()
        return pandas_extended(df)

    def filter_by_entity(self, entity_column, entity):
        df = self.df.copy()
        return pandas_extended(df[df[entity_column]==entity])

    def sort_by(self, column, ascending=False):
        df = self.df.copy()
        return pandas_extended(df.sort_values(by=[column], ascending=ascending))

    def groupBy(self, groupby_column_list, sum_column_list):
        df_groupedBy = self.df.groupby(groupby_column_list)[sum_column_list].sum().reset_index()
        return pandas_extended(df=df_groupedBy)

    def cluster_df(self, cluster_col, list_of_clusters, groupby_column_list, sum_column_list):
        df = self.df.copy()
        df["cluster"]= df[cluster_col].apply(lambda x: x if x in list_of_clusters else 'others')
        df_clustered=df.groupby(['cluster']+groupby_column_list)[sum_column_list].sum().reset_index()
        return pandas_extended(df=df_clustered)

    def to_csv(self, path, name):
        self.df.to_csv("{}/{}.csv".format(path, name), decimal=',')