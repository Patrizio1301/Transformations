from src.sparkSession import arranca_spark
from pyspark.sql import functions as F

spark = arranca_spark(sesion_name="arranca_spark")

events = spark.table("ws_crm.eventos_2")

retail= events.filter("id_persona_1 like 'F%'").filter(events["fecha"] < F.lit("2019-12-01"))

plotingBar_retail = retail.groupBy(["id_persona_1", "id_persona_2"]).agg(F.count("*").alias("transactions"))
plotingBar_retail.show(100)

plotingBar= plotingBar_retail.groupBy("transactions").agg(F.count("*").alias("customers"))

plotingBar.toPandas().to_csv('/home/x260220/PycharmProjects/prediction/src/account_preprocessing/TR_per_customer.csv')



