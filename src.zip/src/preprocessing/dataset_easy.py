import tensorflow as tf
from tensorflow import Tensor


class Datasets(object):
    """Input pipeline using tf.data.dataset API

    DataSet input pipeline which will be used as an input for a model.
    This class separates your input into train and test data and
    cluster your data into batches with size batch_size.

    Attributes
    ----------
    features : tf.Tensor
        features data. This will define the feature space X.
    target : tf.Tensor
        target data. This defines the target space Y.
    batch_size : int
        Batch size for batch/mini-batch optimization. If the
        batch_size is equal to None (by default), the optimization
        will be batch optimization. If batch_size is equal to -1,
        this will be gradient optimization. If batch_size is a
        natural number, mini batch optimization will be applied.
    training_size: float
        Percentage of desired train set. For example, if this
        parameter is initialized with the value 0.8, 80 percentage
        of the input data will be used as the train data.

    Methods
    -------
    sample_size : int
        DataSet sample size. If the given feature and target
        inputs do not concur in their sample size, this method
        will rise an ValueError and this object will be useless.
    dataSet : tf.Tensor
        DataSet. The dataSet is defined as a zipped dataSet with
        the structure (feature, target) for each sample.
    training_data : tf.Tensor
        Training dataSet.
    training_data_op : Operator
        Iterator initializer.
    training_data_next : tf.Tensor
        Next train data batch.
    test_data : tf.Tensor
        Testing dataSet
    test_data_op : Operator
        Iterator initializer.
    test_data_next : tf.Tensor
        Next test data batch.
    """

    def __init__(self, features: Tensor):
        self.dataset = features

    def window_dataset(self, window_size, slice_size):
        """Combines (nests of) input elements into a dataset of (nests of) windows
           in case window_size is not None.

        A "window" is a finite dataset of flat elements of size `size` (or possibly
        fewer if there are not enough input elements to fill the window and
        `drop_remainder` evaluates to false).

        The `stride` argument determines the stride of the input elements, and the
        `shift` argument determines the shift of the window.

        For example, letting {...} to represent a Dataset:

        - `tf.data.Dataset.range(7).window(2)` produces
          `{{0, 1}, {2, 3}, {4, 5}, {6}}`
        - `tf.data.Dataset.range(7).window(3, 2, 1, True)` produces
          `{{0, 1, 2}, {2, 3, 4}, {4, 5, 6}}`
        - `tf.data.Dataset.range(7).window(3, 1, 2, True)` produces
          `{{0, 2, 4}, {1, 3, 5}, {2, 4, 6}}`

        Note that when the `window` transformation is applied to a dataset of
        nested elements, it produces a dataset of nested windows.

        For example:

        - `tf.data.Dataset.from_tensor_slices((range(4), range(4))).window(2)`
          produces `{({0, 1}, {0, 1}), ({2, 3}, {2, 3})}`
        - `tf.data.Dataset.from_tensor_slices({"a": range(4)}).window(2)`
          produces `{{"a": {0, 1}}, {"a": {2, 3}}}`

        Args:
          size: A `tf.int64` scalar `tf.Tensor`, representing the number of elements
            of the input dataset to combine into a window.
          shift: (Optional.) A `tf.int64` scalar `tf.Tensor`, representing the
            forward shift of the sliding window in each iteration. Defaults to
            `size`.
          stride: (Optional.) A `tf.int64` scalar `tf.Tensor`, representing the
            stride of the input elements in the sliding window.
          drop_remainder: (Optional.) A `tf.bool` scalar `tf.Tensor`, representing
            whether a window should be dropped in case its size is smaller than
            `window_size`.

        Returns:
          Dataset: A `Dataset` of (nests of) windows -- a finite datasets of flat
            elements created from the (nests of) input elements.

        """
        if window_size is not None:
            data = self.dataset.window(window_size, slice_size, 1, True)
            func = lambda *window: tf.data.Dataset.zip(tuple([w.batch(window_size) for w in window]))
            data = data.interleave(func,
                                   cycle_length=10,
                                   block_length=10,
                                   num_parallel_calls=4)
            return data
        return self.dataset