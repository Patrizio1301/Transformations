from src.sparkSession import arranca_spark
from pyspark.sql import functions as F

spark = arranca_spark(sesion_name="arranca_spark")

customers = spark.table("ws_crm.eventos_2")

