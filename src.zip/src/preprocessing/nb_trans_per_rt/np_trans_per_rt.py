import pandas as pd
import matplotlib.pyplot as plt

df=pd.read_csv("/home/x260220/PycharmProjects/prediction/src/account_preprocessing/TR_per_customer.csv")
df=df.sort_values("transactions")
trans=df['transactions']
customers=df['customers']
plt.bar(trans.values[:100], customers.values[:100])
plt.savefig('/home/x260220/PycharmProjects/prediction/src/account_preprocessing/nb_trans_per_rt/first.png')
