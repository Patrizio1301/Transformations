import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
import matplotlib as mpl
from matplotlib.colors import ListedColormap
import numpy as np
from dataclasses import dataclass
from pyspark.sql.dataframe import DataFrame

@dataclass
class PlotModel(object):
    df: DataFrame
    path: str
    name: str
    """
    Model for all Santander Vializations

    Attributes:
    -------------
    df: DataFrame
        DataFrame to be implemented in

    Methods:
    --------
    run: None
        Executes the chart and saves it where indicated

    """

    def run(self, *args, **kwargs):
        raise NotImplementedError("To be implemented")

class ColorHandling(object):

    @staticmethod
    def santander_colormap(color):
        theme=plt.get_cmap(color)
        map=theme(np.linspace(0.25, 0.75, 256))
        return ListedColormap(map)

@dataclass
class HistChart(PlotModel):
    x: str
    y: str

    """

    """
    def run(self):
        x = self.df.select(self.x).collect()
        x=[int(row[self.x]) for row in x]
        y= self.df.select(self.y).collect()
        y = [int(row[self.y]) for row in y]
        width = 1
        plt.bar(x, y, width, color="red")
        plt.xlim([0, 31])
        plt.savefig(self.path)

@dataclass
class PieChart(PlotModel):
    labels: str
    sizes: str
    """
    Pie chart for vizualizations
    """

    def run(self):
        sizes = self.df.select(self.sizes).collect()
        sizes=[int(row[self.sizes]) for row in sizes]
        labels= self.df.select(self.labels).collect()
        labels = [str(row[self.labels]) for row in labels]
        fig1, ax1 = plt.subplots(figsize=(10, 10))

        colors=ColorHandling().santander_colormap(color='Reds')
        ax1.set_prop_cycle("color", [colors(1. * i / len(sizes))
                                     for i in range(len(sizes))])

        _, _, _ = ax1.pie(sizes, startangle=90, autopct='%1.1f%%')

        total = sum(sizes)
        plt.legend(
            loc='lower right',
            labels=['%s, %1.1f%%' % (
                l, (float(s) / total) * 100)
                    for l, s in zip(labels, sizes)],
            prop={'size': 10},
            bbox_to_anchor=(1, 0.1),
            bbox_transform=fig1.transFigure
        )
        plt.subplots_adjust(left=0.1, right=0.9, bottom=0.05)
        plt.tight_layout()
        name='{}/{}.png'.format(self.path, self.name)
        plt.savefig(name)

class LollipopChart(PlotModel):
    """
    Lollipop chart for vizualizations
    """
    def __init__(self, input_path):
        super().__init__(input_path)

    def chart(self, x, y, path, title: str,
              y_label: str, y_num: bool=True):
        # prepare data
        x = self.df[x].values.tolist()
        if y_num:
            y = [float(num.replace(",", ".")) for num in self.df[y].values.tolist()]

        # Draw plot
        fig, ax =plt.subplots(
            figsize=(16,10),
            dpi=80
        )

        fig.patch.set_visible(False)

        (markerline, stemlines, baseline)=plt.stem(x, y, "firebrick")

        plt.setp(markerline, marker="o", markersize=5,
                 markeredgewidth=2, color='firebrick')
        plt.setp(stemlines, color='firebrick', linewidth =6)
        plt.setp(baseline, visible=False)


        #Title, Label, Ticks and Ylim
        ttl = ax.title
        ttl.set_position([.5, 1.2])
        ax.set_title(title, fontdict={'size': 22}, y=1.08)
        ax.set_ylabel(y_label)
        ax.set_xticks(x)

        plt.tick_params(
            top=False,
            bottom=True,
            right=False,
            left=True,
            labelleft=True,
            labelbottom=True,
            labeltop=False,
            labelright=False
        )

        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        plt.savefig(path)

class PieDouble(PlotModel):
    """
    Double Pie chart for vizualizations
    """
    def __init__(self, input_path):
        super().__init__(input_path)

    def chart(self, path, title: str, sizes_main, sizes_sub,
              label_main, label_sub, color_main, color_sub):
        bigger = plt.pie(sizes_main, labels=label_main,
                         colors=color_main, startangle=90, frame=True)
        smaller = plt.pie(sizes_sub, labels=label_sub,
                          colors=color_sub, radius=0.7,
                          startangle=90, labeldistance=0.7)
        centre_circle = plt.Circle((0, 0), 0.4, color='white', linewidth=0)
        fig = plt.gcf()
        fig.gca().add_artist(centre_circle)

        plt.axis('equal')
        plt.tight_layout()

        plt.savefig(path)






