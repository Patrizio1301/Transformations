import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
mpl.rcParams['font.size'] = 9.0
from matplotlib.colors import ListedColormap
import numpy as np

class PieChart(object):
    def __init__(self, input_path):
        self.input_path = input_path

    @property
    def df(self):
        return pd.read_csv(self.input_path)

    def chart(self, labels, sizes, path):
        df = self.df.copy().sort_values(by=[sizes], ascending=True)
        sizes = df[sizes].values.tolist()
        labels= df[labels].values.tolist()
        fig1, ax1 = plt.subplots(figsize=(10, 10))

        theme = plt.get_cmap('Reds')
        newcmp = ListedColormap(theme(np.linspace(0.25, 0.75, 256)))
        ax1.set_prop_cycle("color", [newcmp(1. * i / len(sizes))
                                     for i in range(len(sizes))])

        _, _, _ = ax1.pie(sizes, startangle=90, autopct='%1.1f%%')

        total = sum(sizes)
        plt.legend(
            loc='lower right',
            labels=['%s, %1.1f%%' % (
                l, (float(s) / total) * 100)
                    for l, s in zip(labels, sizes)],
            prop={'size': 10},
            bbox_to_anchor=(1, 0.1),
            bbox_transform=fig1.transFigure
        )
        plt.subplots_adjust(left=0.1, right=0.9, bottom=0.05)
        plt.tight_layout()
        plt.savefig(path)

if __name__== "__main__" :
    from utils.spark_session.sparkSession import arranca_spark
    from pandas_utils.pandas_extended import pandas_extended
    spark = arranca_spark(sesion_name="arranca_spark")
    list_categories=['SOC_ANONIMA', 'SEGUROS', 'SOC_LIMITADA', 'ENERGIA', 'COMUNIDAD_PROP', 'TELEFONIA', 'ASOCIACIONES']
    groupby_column_list=[]
    sum_column_list=['trans_frequency']
    input_path="/home/x260220/PycharmProjects/main/src/descriptive_statistics_results/results/spendings_per_category/csv/shares_by_company_monthday/ALLIANZ.csv"
    output_path = "/home/x260220/PycharmProjects/main/src/descriptive_statistics_results/results/spendings_per_category/csv/shares_by_company_monthday"
    df=pandas_extended.read_from_csv(path=input_path).to_csv(path=output_path, name="ALLIANZ_summarized")
    input_path = "/home/x260220/PycharmProjects/main/src/descriptive_statistics_results/results/spendings_per_category/csv/shares_by_category/category_summarized.csv"
    output_path = "/home/x260220/PycharmProjects/main/src/descriptive_statistics_results/results/spendings_per_category/plots/shares_by_category/plot_experiment_4.png"
    PieChart(input_path=input_path).chart(labels="cluster",
                                          sizes="trans_frequency",
                                          path=output_path)







