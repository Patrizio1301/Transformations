
class Operations(object):

    @staticmethod
    def split_df(df, column):
        values=df[column].unique().tolist()
        tables={}
        for value in values:
            tables[value]=df[column==value]
        return tables
