import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
import matplotlib as mpl
from matplotlib.colors import ListedColormap
import numpy as np

class HistChart(object):
    def __init__(self, input_path):
        self.input_path = input_path

    @property
    def df(self):
        return pd.read_csv(self.input_path)

    def chart(self, x, y, path):
        x = self.df[x].values.tolist()
        y= self.df[y].values.tolist()
        width = 1
        plt.bar(x, y, width, color="red")
        plt.xlim([0, 31])
        plt.savefig(path)

