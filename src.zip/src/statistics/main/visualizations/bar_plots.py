import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from src.statistics.main.visualizations.dataframe_operations import Operations as op


class Bar_plots(object):
    def __init__(self, input_path, output_path):
        self.input_path = input_path
        self.output_path = output_path

    @property
    def df(self):
        return pd.read_csv(self.input_path)

    def bar_plot(self, df, x_column, x_nan, y_column, y_nan, name, path):
        x_df=df[x_column].fillna(x_nan).values
        y_df=df[y_column].fillna(y_nan).values
        locs, labels = plt.xticks()
        plt.setp(labels, rotation=45)
        plt.margins(0.1)
        plt.subplots_adjust(bottom=0.5)
        plt.bar(x_df, y_df)
        plt.savefig("{}/{}.png".format(path, name))

    def __call__(self, name,x_column, x_nan, y_column, y_nan, split=False, split_column=None):
        if split:
            splitted=op.split_df(self.df(), split_column)
            for key, value in splitted.items():
                new_name = "{}_{}".format(name, value)
                self.bar_plot(value, x_column, x_nan, y_column, y_nan, new_name, self.output_path)
        else:
            self.bar_plot(self.df, x_column, x_nan, y_column, y_nan, name, self.output_path)


if __name__== "__main__" :
    bar=Bar_plots(input_path="/home/x260220/PycharmProjects/main/src/descriptive_statistics_results/results/spendings/spending_per_category.csv",
                  output_path="/home/x260220/PycharmProjects/main/src/descriptive_statistics_results/results/spendings")

    bar(name="categpry_plot",
        x_column="cat1_nombre",
        x_nan= "undefined",
        y_column="sum_category",
        y_nan=0)

