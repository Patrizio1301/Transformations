from spark_utils.spark_session.sparkSession import arranca_spark
from src.statistics.main.periodic_classification.periodicClassification import Periodicity as Pds

def find_relationships(company, spark, table):
    pds = Pds(spark_session=spark,events=table)
    df = pds.basic_table(
        date_col='fecha_trans',
        group_by_list=['contrato_partenon', 'cif_destino', 'cat3_nombre', 'cat4_nombre'],
        column_list=['fecha_trans', 'importe', 'mensaje'],
        column_length='fecha_trans_list',
        category=company
    )
    df = pds.add_difference_time_series(df, column="fecha_trans_list")
    df = pds.mean(df, column="date_dif_time_serie")
    path = "/home/x260220/PycharmProjects/main/src/descriptive_statistics_results/results/periodicity/{}.csv".format(company)
    df.toPandas().to_csv(path, decimal=',')

# SPARK SESSION
spark = arranca_spark(sesion_name="arranca_spark")

# TimeLine DataFrame
table=spark.table("ws_crm.%s" % "timeline360")

# SEGUROS
#find_relationships(spark=spark, table=table, company="MAPFRE")
#find_relationships(spark=spark, table=table, company="SANITAS")
#find_relationships(spark=spark, table=table, company="ALLIANZ")
find_relationships(spark=spark, table=table, company="MUTUA_MADRILENA")
#find_relationships(spark=spark, table=table, company="AXA")

# TELEFONIA
#find_relationships(spark=spark, table=table, company="TELEFONICA DE ESPANA, S.A.U.")
#find_relationships(spark=spark, table=table, company="VODAFONE")
#find_relationships(spark=spark, table=table, company="ORANGE")
#find_relationships(spark=spark, table=table, company="YOIGO")

# ENERGIA
#find_relationships(spark=spark, table=table, company="ENDESA")
#find_relationships(spark=spark, table=table, company="IBERDROLA")
#find_relationships(spark=spark, table=table, company="GAS_NATURAL")
