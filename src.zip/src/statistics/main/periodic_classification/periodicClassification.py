import datetime
import statistics
import numpy as np
from spark_utils.table_from_database import Table
from src.statistics.main.account_preprocessing.events import Events
from spark_utils.dataFrame_extended.functions import DataFrame_Extended as dfe
from pyspark.sql.functions import udf
from pyspark.sql.functions import UserDefinedFunction
from pyspark.sql.types import ArrayType, FloatType, IntegerType, DoubleType

class Periodicity(object):
    def __init__(self, events, spark_session):
        self.spark_session = spark_session
        self.events = dfe(spark_session=self.spark_session, df=events)

    @classmethod
    def get_events_from_database(cls, spark_session, df_name):
        df_ = Table(spark_session=spark_session, table_name=df_name).table
        return cls(events=df_, spark_session=spark_session)

    @classmethod
    def get_events_from_class(cls,spark_session, df_name, date):
        df_ = Events(spark_session=spark_session, df_name=df_name).events(date)
        return cls(events=df_, spark_session=spark_session)

    def basic_table(self, date_col, group_by_list, column_list, column_length, category):
        return self.events.sort(
            column=date_col
        ).filter(
            sql_condition="cat4_nombre=='{}'".format(category)
        ).collect_list(
            order_by=date_col,
            group_by_list=group_by_list,
            column_list=column_list
        ).list_length(
            column=column_length
        ).filter(
            sql_condition="{}_list_cnt < 7 and {}_list_cnt > 2".format(date_col, date_col)
        )

    @staticmethod
    def difference_dates(dateList):
        def stringToDate(date_time_str):
            return datetime.datetime.strptime(date_time_str, '%Y-%m-%d %H:%M:%S.%f')
        return [stringToDate(t2) - stringToDate(t1) for t1,t2 in zip(dateList[:-1], dateList[1:])]

    def add_difference_time_series(self, df, column):
        def stringToDate(date_time_str):
            return datetime.datetime.strptime(date_time_str, '%Y-%m-%d')
        def get_days(t1, t2):
            delta=stringToDate(t2) - stringToDate(t1)
            return delta.days
        def difference_dates(dateList):
            return [get_days(t1, t2) for t1, t2 in zip(dateList[:-1], dateList[1:])]
        udf_difference_dates= udf(lambda dateList: difference_dates(dateList), ArrayType(IntegerType()))
        return df.select(
            df["*"],
            udf_difference_dates(df[column]).alias("date_dif_time_serie")
        )

    def mean(self, df, column):
        udf_mean_of_list = udf(lambda list: sum(list)/len(list) if len(list) is not 0 else None, DoubleType())
        return df.select(
            df["*"],
            udf_mean_of_list(df[column]).alias("{}_mean".format(column))
        )

    def median(self, df, column):
        udf_var_of_list = udf(lambda list: statistics.median(map(float, list)) if len(list) is not 0 else None, FloatType())
        return df.select(
            df["*"],
            udf_var_of_list(df[column]).alias("{}_median".format(column))
        )

    def variance(self, df, column):
        def mean(lst):
            return sum(lst)/len(lst)
        udf_var_of_list = udf(lambda list: mean([(x - mean(list))**2 for x in list]) if len(list) is not 0 else None, FloatType())
        return df.select(
            df["*"],
            udf_var_of_list(df[column]).alias("{}_variance".format(column))
        )

    def IQR(self, df, column):
        def IQR(list):
            iqr= np.subtract(*np.percentile(list, [75, 25]))
            return iqr if len(list) is not 0 else None
        udf_var_of_list = UserDefinedFunction(IQR, FloatType())
        return df.select(
            df["*"],
            udf_var_of_list(df[column]).alias("{}_IQR".format(column))
        )
