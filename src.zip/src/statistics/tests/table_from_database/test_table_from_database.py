import src.statistics.tests.testbase as testbase
import pyspark.tests as tests
import unittest
import sys
from pyspark.context import SparkContext

class PySparkTestCase(unittest.TestCase):

    def setUp(self):
        self.sc = SparkContext('local[4]' , batchSize=2)

    def tearDown(self):
        self.sc.stop()

def wordCount(rdd):
    wcntRdd = rdd.flatMap(lambda line: line.split()). \
        map(lambda word: (word, 1)). \
        reduceByKey(lambda fa, fb: fa + fb)
    return wcntRdd


class TestWordCount(PySparkTestCase):
    def test_word_count(self):
        rdd = self.sc.parallelize(["a b c d", "a c d e", "a d e f"])
        res = wordCount(rdd)
        res = res.collectAsMap()
        expected = {"a": 3, "b": 1, "c": 2, "d": 3, "e": 2, "f": 1}
        self.assertEqual(res, expected)


if __name__ == '__main__':
    unittest.main()