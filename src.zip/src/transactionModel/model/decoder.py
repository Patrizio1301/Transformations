import tensorflow as tf
from tensorflow.keras import layers


class BahdanauAttention(layers.Layer):
  def __init__(self, units):
    super(BahdanauAttention, self).__init__()
    self.W1 = tf.keras.layers.Dense(units)
    self.W2 = tf.keras.layers.Dense(units)
    self.V = tf.keras.layers.Dense(1)

  def call(self, query, values):
    # query hidden state shape == (batch_size, hidden size)
    # query_with_time_axis shape == (batch_size, 1, hidden size)
    # values shape == (batch_size, max_len, hidden size)
    # we are doing this to broadcast addition along the time axis to calculate the score
    query_with_time_axis = tf.expand_dims(query, 1)

    # score shape == (batch_size, max_length, 1)
    # we get 1 at the last axis because we are applying score to self.V
    # the shape of the tensor before applying self.V is (batch_size, max_length, units)
    score = self.V(tf.nn.tanh(
        self.W1(query_with_time_axis) + self.W2(values)))

    # attention_weights shape == (batch_size, max_length, 1)
    attention_weights = tf.nn.softmax(score, axis=1)

    # context_vector shape after sum == (batch_size, hidden_size)
    context_vector = attention_weights * values
    context_vector = tf.reduce_sum(context_vector, axis=1)

    return context_vector, attention_weights

class Decoder(layers.Layer):
  def __init__(self, vocab_size, dec_units, embedding_dim, input_steps):
    super(Decoder, self).__init__()
    self.dec_units = dec_units
    self.lstm = layers.LSTM(
        self.dec_units,
        return_sequences=True,
        return_state=True,
        recurrent_initializer='glorot_uniform'
    )
    self.cnn=layers.TimeDistributed(layers.Conv1D(filters=8, kernel_size=4, activation='relu', input_shape=(32,1)))
    self.max=layers.TimeDistributed(layers.MaxPooling1D(pool_size=8))
    self.flatten=layers.TimeDistributed(layers.Flatten())
    #self.embedding = tf.keras.layers.Embedding(vocab_size, embedding_dim)
    # used for attention
    #self.attention = layers.TimeDistributed(BahdanauAttention(self.dec_units))

  def call(self, x, hidden, enc_output):
    # enc_output shape == (batch_size, max_length, hidden_size)

    #context_vector, attention_weights = self.attention([hidden[0], enc_output])

    # x shape after passing through embedding == (batch_size, 1, embedding_dim)

    # x shape after concatenation == (batch_size, 1, embedding_dim + hidden_size)
    #x = tf.concat([context_vector, x], axis=-1)

    enc_output = tf.expand_dims(enc_output, 3)
    print("HAAAAAAAAAAAAAAAA", enc_output.shape)

    x=self.cnn(enc_output)
    print("CNN1", x.shape)

    x = self.max(x)

    print("CNNNNNNNNNNNNNNNNNN", x.shape)

    x = self.flatten(x)

    print("FLATTTTENNNNN", x.shape)

    # passing the concatenated vector to the GRU
    output, state , _ = self.lstm(x, initial_state=hidden)

    return output, state, state