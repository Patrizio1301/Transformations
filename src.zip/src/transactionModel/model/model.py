import tensorflow as tf
from tensorflow.keras.layers import Embedding, Reshape, Input, Concatenate, LSTM, Dense, Dropout, TimeDistributed
tf.keras.backend.clear_session() # For easy reset of notebook state.
from src.transactionModel.model.embedding import Embedding_Input
from src.transactionModel.model.encoder import Encoder
from src.transactionModel.model.decoder import Decoder


class TransactionModel(tf.keras.Model):
    def __init__(
            self,
            input_steps,
            total_customer,
            total_cif,
            total_month,
            total_day,
            total_category,
            total_dayofyear,
            customer_embedding_length,
            category_embedding_length,
            cif_embedding_length,
            dayofyear_embedding_length,
            month_embedding_length,
            day_embedding_length,
            dim_concat
    ):
        super(TransactionModel, self).__init__()
        self.input_steps=input_steps
        self.total_customer=total_customer
        self.total_cif=total_cif
        self.total_month=total_month
        self.total_day=total_day
        self.total_category=total_category
        self.total_dayofyear=total_dayofyear
        self.customer_embedding_length=customer_embedding_length
        self.category_embedding_length=category_embedding_length
        self.cif_embedding_length=cif_embedding_length
        self.dayofyear_embedding_length=dayofyear_embedding_length
        self.month_embedding_length=month_embedding_length
        self.day_embedding_length=day_embedding_length
        self.dim_concat=dim_concat

        self.customer=Embedding_Input(
            input_steps=self.input_steps,
            name='customer',
            vocab_size=self.total_customer,
            embed_size=self.customer_embedding_length
        )

        self.year = Reshape(
            target_shape=(self.input_steps, 1),
            name="reshape_year"
        )

        self.amount = Reshape(
            target_shape=(self.input_steps, 1),
            name="reshape_amount"
        )

        self.month=Embedding_Input(
            input_steps=self.input_steps,
            name='month',
            vocab_size=self.total_month,
            embed_size=self.month_embedding_length
        )

        self.day=Embedding_Input(
            input_steps=self.input_steps,
            name='day',
            vocab_size=self.total_day,
            embed_size=self.day_embedding_length
        )

        self.dayofyear=Embedding_Input(
            input_steps=self.input_steps,
            name='dayofyear',
            vocab_size=self.total_dayofyear,
            embed_size=self.dayofyear_embedding_length
        )

        self.cif=Embedding_Input(
            input_steps=self.input_steps,
            name='cif',
            vocab_size=self.total_cif,
            embed_size=self.cif_embedding_length
        )

        self.category=Embedding_Input(
            input_steps=self.input_steps,
            name='category',
            vocab_size=self.total_category,
            embed_size=self.category_embedding_length
        )

        self.concat = Concatenate(axis=2)

        self.lstm_encoder=Encoder(
            enc_units=32
        )

        self.lstm_decoder_month = Decoder(
            vocab_size=self.total_month,
            embedding_dim=self.month_embedding_length,
            dec_units=32,
            input_steps=self.input_steps
        )

        self.lstm_decoder_day= Decoder(
            vocab_size=self.total_day,
            embedding_dim=self.day_embedding_length,
            dec_units=32,
            input_steps=self.input_steps
        )

        self.lstm_decoder_customer = Decoder(
            vocab_size=self.total_customer,
            embedding_dim=self.customer_embedding_length,
            dec_units=32,
            input_steps=self.input_steps
        )

        self.lstm_decoder_cif= Decoder(
            vocab_size=self.total_cif,
            embedding_dim=self.cif_embedding_length,
            dec_units=32,
            input_steps=self.input_steps
        )

        self.dense_month = Dense(256, activation='relu')
        self.output_month = Dense(total_month, activation='softmax', name="output_month")

        self.dense_day= Dense(256, activation='relu')
        self.output_day = Dense(total_day, activation='softmax', name="output_day")

        self.dense_customer = Dense(256, activation='relu')
        self.output_customer = Dense(total_customer, activation='softmax', name="output_customer")

        self.dense_cif = Dense(256, activation='relu')
        self.output_cif = Dense(total_cif, activation='softmax', name="output_cif")

    def call(self, inputs):

        customer=self.customer(inputs[0])
        year = self.year(inputs[1])
        month = self.month(inputs[2])
        day = self.day(inputs[3])
        dayofyear = self.dayofyear(inputs[4])
        amount = self.amount(inputs[5])
        cif = self.cif(inputs[6])
        category = self.customer(inputs[7])

        concat=self.concat(
            [customer, year, month, day, dayofyear, amount, cif, category]
        )

        encoder_outputs, state_h, state_c =self.lstm_encoder(concat)
        encoder_states = [state_h, state_c]

        decoder_month, _, _=self.lstm_decoder_month(
            encoder_outputs,
            hidden= encoder_states,
            enc_output=encoder_outputs
        )
        decoder_day, _, _ = self.lstm_decoder_day(
            encoder_outputs,
            hidden=encoder_states,
            enc_output=encoder_outputs
        )
        decoder_customer, _, _=self.lstm_decoder_customer(
            encoder_outputs,
            hidden= encoder_states,
            enc_output=encoder_outputs
        )
        decoder_cif, _, _ =self.lstm_decoder_cif(
            encoder_outputs,
            hidden=encoder_states,
            enc_output=encoder_outputs
        )


        dense_month = self.dense_month(decoder_month)
        output_month = self.output_month(dense_month)

        dense_day = self.dense_day(decoder_day)
        output_day = self.output_day(dense_day)

        dense_customer = self.dense_customer(decoder_customer)
        output_customer = self.output_customer(dense_customer)

        dense_cif = self.dense_cif(decoder_cif)
        output_cif = self.output_cif(dense_cif)

        print('output_month', output_month.shape)
        print('output_day', output_day.shape)
        print('output_cif', output_cif.shape)
        print('output_customer', output_customer.shape)

        return {'output_month': output_month, 'output_day': output_day, 'output_cif': output_cif, 'output_customer': output_customer}