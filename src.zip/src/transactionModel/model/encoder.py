import tensorflow as tf
from tensorflow.keras import layers

class Encoder(layers.Layer):
  def __init__(self, enc_units):
    super(Encoder, self).__init__()
    self.enc_units = enc_units
    self.lstm = tf.keras.layers.LSTM(
        self.enc_units,
        return_sequences=True,
        return_state=True,
        recurrent_initializer='glorot_uniform'
    )

  def call(self, x):
    output, state_h, state_c= self.lstm(x)
    return output, state_h, state_c