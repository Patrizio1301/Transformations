from tensorflow.keras import layers
from tensorflow.keras.layers import Embedding, Reshape


class Embedding_Input(layers.Layer):
  def __init__(self, input_steps, name, vocab_size, embed_size):
    super(Embedding_Input, self).__init__()
    self.input_steps = input_steps
    self.vocab_size=vocab_size
    self.embed_size=embed_size
    self.embedding_layer = Embedding(
        input_dim=self.vocab_size,
        output_dim=self.embed_size,
        input_length=self.input_steps,
        name='embedding_{}'.format(name)
    )
    self.reshaped_input=Reshape(
        target_shape=(self.input_steps,self.embed_size,),
        name='reshape_{}'.format(name)
    )


  def call(self, input):
    embedding_lay = self.embedding_layer(input)
    return self.reshaped_input(embedding_lay)