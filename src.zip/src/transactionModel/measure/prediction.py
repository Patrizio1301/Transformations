import tensorflow as tf
import numpy as np

class Prediction(object):
    def __init__(self, model, x_test, y_test, input_steps):
        self.model=model
        self.input_steps=input_steps
        self.x_test=x_test
        self.y_test=y_test

    def input(self):
        data_pred = [np.array([np.array(x) for x in self.x_test])]
        arra = data_pred[0]
        return [arra[0], arra[1], arra[2], arra[3], arra[4], arra[5], arra[6], arra[7]]

    @property
    def prediction(self):
        print(self.input())
        return self.model.predict(self.input())

    @property
    def output(self):
        month = np.reshape(self.y_test[0], (self.input_steps,))
        day = np.reshape(self.y_test[1], (self.input_steps,))
        cif = np.reshape(self.y_test[2], (self.input_steps,))
        customer = np.reshape(self.y_test[3], (self.input_steps,))
        return np.array([customer, cif, month, day])

    @property
    def output_pred(self):
        month_pred = self.prediction[0].argmax(axis=2)
        day_pred = self.prediction[1].argmax(axis=2)
        cif_pred = self.prediction[2].argmax(axis=2)
        customer_pred = self.prediction[3].argmax(axis=2)
        return np.array([customer_pred[0], cif_pred[0], month_pred[0], day_pred[0]])




