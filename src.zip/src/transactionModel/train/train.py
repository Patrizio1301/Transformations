import tensorflow as tf
import sys
from tensorflow.keras.callbacks import ModelCheckpoint as ModelCheckPoint

def coompliation(
        model,
        learning_rate
):
    adamOpti = tf.keras.optimizers.Adam(lr=learning_rate)
    model.compile(loss=['sparse_categorical_crossentropy', 'sparse_categorical_crossentropy', 'sparse_categorical_crossentropy', 'sparse_categorical_crossentropy'],
                  optimizer=adamOpti,
                  metrics={'output_1':'sparse_categorical_accuracy',
                           'output_2':'sparse_categorical_accuracy',
                           'output_3':'sparse_categorical_accuracy',
                           'output_4':'sparse_categorical_accuracy'})



def training(
        model,
        epochs: int,
        steps_per_epoch: int,
        validation_steps: int,
        train_dataset,
        test_dataset,
        weight_path
):

    print('*' * 20)
    print('Training model...')
    sys.stdout.flush()
    checkpoint = ModelCheckPoint(
        filepath=weight_path+'weights.{epoch:02d}',
        verbose=1,
        save_weights_only=True,
        save_format='tf'
    )

    history = model.fit(
        train_dataset,
        epochs=epochs,
        steps_per_epoch=steps_per_epoch,
        validation_steps=validation_steps,
        verbose=1,
        validation_data=test_dataset,
        callbacks=[checkpoint, LearningRateReducerCb()]
    )

    print('*' * 20)
    print('Plotting history...')
    sys.stdout.flush()
    #plot_training_info(['loss'], True, history.history)
    print('*' * 20)
    print('Evaluating best model...')
    sys.stdout.flush()
    #metrics = model.evaluate(test_data, steps=10)
    #print(metrics)

class LearningRateReducerCb(tf.keras.callbacks.Callback):

  def on_epoch_end(self, epoch, logs={}):
    old_lr = self.model.optimizer.lr.read_value()
    new_lr = old_lr * 0.95
    print("\nEpoch: {}. Reducing Learning Rate from {} to {}".format(epoch, old_lr, new_lr))
    self.model.optimizer.lr.assign(new_lr)

