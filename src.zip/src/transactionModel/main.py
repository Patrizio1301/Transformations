from src.transactionModel.model.model import TransactionModel
from src.transactionModel.train.train import training, coompliation
from src.transactionModel.input.input import Input
import tensorflow as tf

class Main(object):
    TOTAL_CIF = 42+100
    TOTAL_CAT = 3 + 100
    TOTAL_CUSTOMER = 40+100
    TOTAL_MONTH = 12+100
    TOTAL_DAYS = 31+100
    TOTAL_DAYOFYEAR=365+100
    DIM_CONCAT = 15 + 10 + 6 + 1 +50 + 1+ 20 + 2

    def __init__(
            self,
            weight_path,
            input_path,
            steps_per_epoch: int=1,
            validation_steps: int=1,
            step: int=1,
            input_steps = 3,
            future_steps=3,
            batch_size = 3,
            customer_embdg_len=10,
            month_embdg_len = 6,
            day_embdg_len = 15,
            cif_embdg_len = 20,
            cat_embdg_len=2,
            dayofyear_embdg_len=50,
            epochs = 70,
            learning_rate = 0.00005
    ):
        self.weight_path=weight_path
        self.input_path=input_path
        self.steps_per_epoch=steps_per_epoch
        self.validation_steps=validation_steps
        self.step=step
        self.epochs=epochs
        self.input_steps=input_steps
        self.future_steps=future_steps
        self.batch_size=batch_size
        self.customer_embdg_len=customer_embdg_len
        self.month_embdg_len=month_embdg_len
        self.day_embdg_len=day_embdg_len
        self.cif_embdg_len=cif_embdg_len
        self.cat_embdg_len=cat_embdg_len
        self.dayofyear_embdg_len=dayofyear_embdg_len
        self.learning_rate=learning_rate
        self.model=self.model()


    @property
    def input(self):
        return Input(
            batch_size=self.batch_size,
            input_steps=self.input_steps,
            future_steps=self.future_steps,
            path=self.input_path
        )

    def model(self):
        return TransactionModel(
            input_steps=self.input_steps,
            total_month=self.TOTAL_MONTH,
            total_day=self.TOTAL_DAYS,
            total_cif=self.TOTAL_CIF,
            total_customer=self.TOTAL_CUSTOMER,
            total_category=self.TOTAL_CAT,
            total_dayofyear=self.TOTAL_DAYOFYEAR,
            customer_embedding_length=self.customer_embdg_len,
            month_embedding_length=self.month_embdg_len,
            category_embedding_length=self.cat_embdg_len,
            day_embedding_length=self.day_embdg_len,
            cif_embedding_length=self.cif_embdg_len,
            dayofyear_embedding_length=self.dayofyear_embdg_len,
            dim_concat=self.DIM_CONCAT
        )

    def compilation(self):
        return coompliation(
            model=self.model,
            learning_rate=self.learning_rate
        )

    def training(self):
        return training(
            model=self.model,
            weight_path=self.weight_path,
            epochs=self.epochs,
            steps_per_epoch=self.steps_per_epoch,
            validation_steps=self.validation_steps,
            train_dataset=self.input.train_dataset,
            test_dataset=self.input.test_dataset
        )

    def save(self):
        self.model.save(self.path)

    def load(self):
        tf.keras.models.load_model(self.path)